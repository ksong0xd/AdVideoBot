//
//  AdVideoBot.h
//  AdVideoBot
//
//  Created by Kyungsuk Song on 10/24/17.
//  Copyright © 2017 Kyungsuk Song. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AdVideoBot.
FOUNDATION_EXPORT double AdVideoBotVersionNumber;

//! Project version string for AdVideoBot.
FOUNDATION_EXPORT const unsigned char AdVideoBotVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdVideoBot/PublicHeader.h>


